#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMenuBar"
#include "QMenu"
#include "QAction"
#include "QGroupBox"
#include "QPushButton"
#include "QHBoxLayout"
#include "QGridLayout"
#include "QRadioButton"
#include "QFormLayout"
#include "QComboBox"
#include "QSpinBox"
#include "QLabel"
#include "QLineEdit"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    CreatMenu();
    HorizonCreatGroupBox();
    HiGridLayout();
    createPushButtonGroup();
    FormLayout();

    //QVBoxLayout *mainLayout = new QVBoxLayout;
    //mainLayout->setMenuBar(MenuBar);
    //mainLayout->setMenuBar(Menubar);
    //mainLayout->addWidget(groupbox);
    //setLayout(mainLayout);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::CreatMenu()
{
    Menubar = new QMenuBar(this);
    Menu = new QMenu(tr("&File"), this);
    Action =Menu->addAction(tr("E&xit"));
    Menubar->addMenu(Menu);
    connect(Action,SIGNAL(triggered()),this,SLOT(close()));

}

void MainWindow::HorizonCreatGroupBox()
{
    groupbox = new QGroupBox(this);
    QPushButton *button1 = new QPushButton("Button_1");
       QPushButton *button2 = new QPushButton("Button_2");
       QPushButton *button3 = new QPushButton("Button_3");
       QPushButton *button4 = new QPushButton("Button_4");
       QPushButton *button5 = new QPushButton("Button_5");

       QHBoxLayout *layout = new QHBoxLayout;
       layout->addWidget(button1);
       layout->addWidget(button2);
       layout->addWidget(button3);
       layout->addWidget(button4);
       layout->addWidget(button5);
       groupbox->setLayout(layout);
       groupbox->setGeometry(0,30,400,50);//trai(phai)..tren(duoi)..dai..rong
       groupbox->show();
       connect(button1,SIGNAL(clicked(bool)),this,SLOT(close()));
       groupbox->setTitle("HorizonCreatGroup");

}

void MainWindow::HiGridLayout()
{
    groupbox = new QGroupBox(this);
    groupbox->setCheckable(true);
    groupbox->setChecked(false);
    QRadioButton *radio1 = new QRadioButton(tr("Radio button 1"));
    QRadioButton *radio2 = new QRadioButton(tr("Radio button 2"));
    QRadioButton *radio3 = new QRadioButton(tr("Radio button 3"));
    radio1->setCheckable(true);
    QVBoxLayout *vbox = new QVBoxLayout;
        vbox->addWidget(radio1);
        vbox->addWidget(radio2);
        vbox->addWidget(radio3);
   groupbox->setLayout(vbox);
   groupbox->setGeometry(0,75,150,150);
   groupbox->setTitle("Checkbox");
   groupbox->show();
}

void MainWindow::createPushButtonGroup()
{
    groupbox = new QGroupBox(this);
    groupbox->setCheckable(true);
    groupbox->setChecked(false);
    QPushButton *pushButton = new QPushButton(tr("&Normal Button"));
        QPushButton *toggleButton = new QPushButton(tr("&Toggle Button"));
        toggleButton->setCheckable(true);
        toggleButton->setChecked(true);
        QPushButton *flatButton = new QPushButton(tr("&Flat Button"));
        flatButton->setFlat(true);
        QPushButton *popupButton = new QPushButton(tr("Pop&up Button"));
        QMenu *menu = new QMenu(this);
        menu->addAction(tr("&First Item"));
        menu->addAction(tr("&Second Item"));
        menu->addAction(tr("&Third Item"));
        menu->addAction(tr("F&ourth Item"));
        popupButton->setMenu(menu);
        QVBoxLayout *bbox = new QVBoxLayout;
        bbox->addWidget(pushButton);
        bbox->addWidget(toggleButton);
        bbox->addWidget(flatButton);
        bbox->addWidget(popupButton);
               //vbox->addStretch(1);
        groupbox->setLayout(bbox);
        groupbox->setGeometry(150,75,150,150);
        groupbox->setTitle("Push button");
        groupbox->show();
}

void MainWindow::FormLayout()
{
    groupbox = new QGroupBox(this);
    QFormLayout *layout1 = new QFormLayout;
    layout1->addRow(new QLabel(tr("Line 1:")), new QLineEdit);
    layout1->addRow(new QLabel(tr("Line 2, long text:")), new QComboBox);
    layout1->addRow(new QLabel(tr("Line 3:")), new QSpinBox);
    groupbox->setLayout(layout1);
    groupbox->setGeometry(0,225,400,100);
    groupbox->setTitle("Form Layout");
    groupbox->show();
}
