#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "QMenuBar"
#include "QMenu"
#include "QAction"
#include "QGroupBox"
#include "QPushButton"
#include "QGridLayout"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    void CreatMenu();
    void HorizonCreatGroupBox();
    void HiGridLayout();
    void createPushButtonGroup();
    void FormLayout();

    QMenuBar *Menubar;
    QGroupBox *groupbox;
    QGridLayout *GLayout;

    QMenu *Menu;
    QAction *Action;
};

#endif // MAINWINDOW_H
